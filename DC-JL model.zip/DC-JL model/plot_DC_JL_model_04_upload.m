%% DC-JL model plotting for freeze-thaw conditions
% This script:
% 1) Defines DC-JL model parameters for multiple freeze-thaw conditions
% 2) Computes model-predicted deviatoric stress-strain curves
% 3) Stores all predicted curves in a matrix
% 4) Produces a publication-style figure
%
% Usage:
% - Make sure DCJL_model.m is on the MATLAB path.
% - Run this script directly in MATLAB.
% - The script generates a figure and saves the computed results to
%   dcjl_results.mat.
%
% Experimental scope:
% - This program is established based on the present experimental dataset
%   with an initial water content of 7.5% and a confining pressure of 50 kPa.
% - The experimentally supported freeze-thaw range is N = 0 to 20 cycles.
% - The maximum freeze-thaw degradation rates are taken as:
%       K1* = 40%
%       K2* = 25%
% - The curves for N = 30 and N = infinity are included as extended
%   visualization / extrapolated reference conditions.

clc
close all

%% Step 1: Check dependency
if exist('DCJL_model', 'file') ~= 2
    error('DCJL_model.m was not found on the MATLAB path.');
end

%% Step 2: Input model parameters
% Each entry corresponds to one freeze-thaw condition

es  = [0.016 0.020 0.025 0.040 0.045 0.050 0.055 0.070];   % Yield strain
ef  = [0.020 0.025 0.030 0.045 0.050 0.055 0.060 0.070];   % Failure strain
E0  = [22475 20363 18629 14340 13840 13555 13520 13500];   % Initial elastic modulus, kPa
TSS = [259.93 252.04 229.98 217.70 210.58 205.95 190.12 181.94]; % Peak strength, kPa
wi  = [0.160 0.153 0.132 0.111 0.092 0.063 0.040 0.000];   % Comprehensive weighting factor

% Freeze-thaw cycle labels for legend
Nlabels = ["N = 0","N = 2","N = 5","N = 10", ...
           "N = 15","N = 20","N = 30","N = \infty"];

nCase = numel(es);

assert(isequal(numel(ef), nCase, numel(E0), nCase, numel(TSS), nCase, numel(wi), nCase), ...
    'All parameter arrays must have the same length.');
assert(numel(Nlabels) == nCase, ...
    'The number of legend labels must match the number of cases.');

%% Step 3: Define the strain grid
% x is kept in decimal form for all calculations.
% xPlot is converted to percent only for plotting.

x = (0:0.0025:0.30).';   % Strain in decimal form
xPlot = 100 * x;        % Strain in percent for plotting

%% Step 4: Compute the DC-TL response for all cases
Yfit = zeros(numel(x), nCase);
URS  = zeros(1, nCase);

for i = 1:nCase
    assert(wi(i) >= 0 && wi(i) <= 1, 'wi must be within [0, 1].');
    assert(es(i) > 0 && ef(i) >= es(i), 'The condition 0 < es <= ef must hold.');

    [yFit_i, ~] = DCJL_model(x, E0(i), TSS(i), wi(i), es(i), ef(i));
    yFit_i = yFit_i(:);

    assert(numel(yFit_i) == numel(x), ...
        'The output length of DCTL_model must match the length of x.');
    assert(all(isfinite(yFit_i)), ...
        'DCJL_model returned NaN or Inf values.');

    Yfit(:, i) = yFit_i;
    URS(i) = TSS(i) * (1 - wi(i));
end

%% Step 5: Create a publication-style figure
fig = figure( ...
    'Color', 'w', ...
    'Units', 'centimeters', ...
    'Position', [4, 4, 9.5, 6.5]);

ax = axes('Parent', fig);
hold(ax, 'on');

% Color palette
cmap = lines(nCase);

%% Step 6: Plot filled regions and model curves
hFit = gobjects(1, nCase);

for i = 1:nCase
    % Light fill under each curve
    fill(ax, ...
        [xPlot; flipud(xPlot)], ...
        [zeros(size(x)); flipud(Yfit(:, i))], ...
        cmap(i, :), ...
        'FaceAlpha', 0.03, ...
        'EdgeColor', 'none', ...
        'HandleVisibility', 'off');

    % Model curve
    hFit(i) = plot(ax, xPlot, Yfit(:, i), ...
        'Color', cmap(i, :), ...
        'LineWidth', 1.6);
end

%% Step 7: Add reference lines
for i = 1:nCase
    xline(ax, 100 * es(i), '--', ...
        'Color', [0.30 0.30 0.30], ...
        'LineWidth', 0.7, ...
        'HandleVisibility', 'off');

    xline(ax, 100 * ef(i), ':', ...
        'Color', [0.50 0.50 0.50], ...
        'LineWidth', 0.7, ...
        'HandleVisibility', 'off');

    yline(ax, URS(i), '--', ...
        'Color', [0.75 0.20 0.20], ...
        'LineWidth', 0.7, ...
        'HandleVisibility', 'off');
end

%% Step 8: Format axes
ax.Box = 'on';
ax.Layer = 'top';
ax.LineWidth = 1.0;
ax.FontName = 'Times New Roman';
ax.FontSize = 9;
ax.TickDir = 'in';
ax.TickLength = [0.018 0.018];
ax.XMinorTick = 'on';
ax.YMinorTick = 'on';
ax.XGrid = 'on';
ax.YGrid = 'on';
ax.GridLineStyle = '--';
ax.GridAlpha = 0.12;
ax.MinorGridAlpha = 0.08;

xlabel(ax, 'Strain (%)', ...
    'FontName', 'Times New Roman', ...
    'FontSize', 10);

ylabel(ax, 'Stress, \sigma (kPa)', ...
    'FontName', 'Times New Roman', ...
    'FontSize', 10);

title(ax, {'DC-JL Model under Different Freeze-Thaw Cycles', ...
           }, ...
    'FontName', 'Times New Roman', ...
    'FontSize', 10, ...
    'FontWeight', 'normal');

xlim(ax, [0 30]);
ylim(ax, [0 1.08 * max(Yfit(:))]);

%% Step 9: Create legend without border
lgd = legend(ax, hFit, Nlabels, ...
    'Location', 'best', ...
    'Interpreter', 'tex');
lgd.Box = 'off';
lgd.FontName = 'Times New Roman';
lgd.FontSize = 8;
lgd.AutoUpdate = 'off';

%% Step 10: Save esults
save('dctl_results.mat', 'es', 'ef', 'E0', 'TSS', 'wi', 'x', 'xPlot', 'Yfit', 'URS', 'Nlabels');

% Optional high-resolution export
% exportgraphics(fig, 'dcjl_model_plot.png', 'Resolution', 600);
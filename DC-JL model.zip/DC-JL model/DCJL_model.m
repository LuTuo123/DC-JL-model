%% DC-JL 模型打包函数

function [y_fit, dPl_So] = DCJL_model(x_, E0, TSS, wi, es, ef)
    % 输入：
    % x    - 自变量
    % E0   - 初始模量
    % TSS  - 总应变
    % wi   - 权重系数
    % es   - 屈服应变
    
    % 计算应变软化项 q(x)
    a = 1 / E0;                  % a = 1 / E0
    m = 1 / TSS - 2 / (E0 * ef); % m = 1 / MSS - 2 / (E0 * es)
    l = 1 / (E0 * ef^2);         % l = 1 / (E0 * es^2)
    So = x_ ./ (a + m * x_ + l * x_.^2); % 计算 q(x)
    
    % 计算塑性项 p(x)
    p = max((1 - (x_ / es).^2), 0);
    b = 1 / TSS;          % b = 1 / MSS
    Pl = (x_.^p) ./ (a * p + b * x_.^p); % 计算 p(x)
    
    % 计算拟合值 y_fit = wi * q + (1 - wi) * p
    y_fit = wi * So + (1 - wi) * Pl;
    
    % 计算塑性项导数 dPl
    numer = a .* x_.^(x_.^2 / es^2) .* ...
           (2 .* x_.^4 .* log(x_) + es^4 + x_.^4 - 2 .* es.^2 .* x_.^2 .* log(x_));
    
    denom = (a .* es.^2 .* x_.^(x_.^2 / es^2) - ...
             a .* x_.^(x_.^2 / es^2) .* x_.^2 + ...
             b .* es.^2 .* x_).^2;
    
    dPl = (1 - wi) .* numer ./ denom;
    
    % 计算应变软化项导数 dSo
    dSo = wi .* (a - l .* x_.^2) ./ (a + m .* x_ + l .* x_.^2).^2;
    
    % 总导数 dPl_So
    dPl_So = dPl + dSo;
    
end
